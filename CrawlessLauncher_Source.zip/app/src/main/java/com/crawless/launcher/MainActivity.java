package com.crawless.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.widget.*;
import org.json.*;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String DEFAULT_URL =
        "https://www.dropbox.com/scl/fi/wq4xu63rhv0lmn6zks606/servers.json?rlkey=pv3hq5fzqa7kixqkle6zjbi5w&st=xgk56x02&dl=1";
    private EditText urlField;
    private LinearLayout serverList;
    private TextView status;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("crawless_launcher", MODE_PRIVATE);
        buildUi();
        urlField.setText(prefs.getString("servers_url", DEFAULT_URL));
        loadServers();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(16,16,16));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("CRAWLESS ROLEPLAY");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("OFFICIAL GAME LAUNCHER");
        subtitle.setTextColor(Color.rgb(244,67,54));
        subtitle.setTextSize(12);
        subtitle.setPadding(0, dp(4), 0, dp(20));
        root.addView(subtitle);

        TextView label = new TextView(this);
        label.setText("Servers.json Dropbox URL");
        label.setTextColor(Color.WHITE);
        label.setTextSize(15);
        root.addView(label);

        urlField = new EditText(this);
        urlField.setSingleLine(false);
        urlField.setMinLines(2);
        urlField.setTextSize(13);
        urlField.setHint("Paste your Dropbox link here");
        urlField.setHintTextColor(Color.GRAY);
        urlField.setTextColor(Color.WHITE);
        urlField.setLinkTextColor(Color.rgb(244,67,54));
        urlField.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                              android.text.InputType.TYPE_TEXT_VARIATION_URI |
                              android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        urlField.setPadding(dp(12), dp(8), dp(12), dp(8));
        root.addView(urlField, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button save = makeButton("SAVE URL");
        Button load = makeButton("LOAD SERVERS");
        actions.addView(save, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1);
        lp.leftMargin = dp(8);
        actions.addView(load, lp);
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, -2);
        actionLp.topMargin = dp(12);
        root.addView(actions, actionLp);

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        status.setPadding(0, dp(16), 0, dp(10));
        root.addView(status);

        TextView heading = new TextView(this);
        heading.setText("AVAILABLE SERVERS");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(17);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setPadding(0, dp(8), 0, dp(8));
        root.addView(heading);

        serverList = new LinearLayout(this);
        serverList.setOrientation(LinearLayout.VERTICAL);
        root.addView(serverList);

        save.setOnClickListener(v -> {
            String value = urlField.getText().toString().trim();
            if (!validUrl(value)) {
                status.setText("Please enter a valid HTTPS URL.");
                return;
            }
            prefs.edit().putString("servers_url", value).apply();
            hideKeyboard();
            status.setText("Configuration saved on this device.");
        });
        load.setOnClickListener(v -> {
            String value = urlField.getText().toString().trim();
            if (!validUrl(value)) {
                status.setText("Please enter a valid HTTPS URL.");
                return;
            }
            prefs.edit().putString("servers_url", value).apply();
            hideKeyboard();
            loadServers();
        });

        setContentView(scroll);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190,35,35)));
        return b;
    }

    private void loadServers() {
        String url = urlField.getText().toString().trim();
        if (!validUrl(url)) {
            status.setText("Enter a valid HTTPS Dropbox URL to load servers.");
            return;
        }
        status.setText("Loading server list…");
        serverList.removeAllViews();

        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                String directUrl = makeDropboxDirect(url);
                connection = (HttpURLConnection) new URL(directUrl).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                connection.setRequestProperty("Accept", "application/json");
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                InputStream input = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8));
                StringBuilder body = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) body.append(line).append('\n');
                reader.close();
                JSONArray items = extractServers(body.toString());
                runOnUiThread(() -> {
                    serverList.removeAllViews();
                    if (items.length() == 0) {
                        addServerCard("No servers found", "The JSON loaded, but no server array was detected. Check your servers.json structure.");
                        status.setText("Loaded JSON, but no server entries were detected.");
                        return;
                    }
                    for (int i = 0; i < items.length(); i++) {
                        Object item = items.opt(i);
                        if (item instanceof JSONObject) {
                            JSONObject obj = (JSONObject) item;
                            String name = firstString(obj, "name", "server_name", "title", "hostname", "label");
                            String address = firstString(obj, "ip", "address", "host", "hostname", "server_ip");
                            String port = firstString(obj, "port", "server_port");
                            if (name.isEmpty()) name = "Server " + (i + 1);
                            String detail = address;
                            if (!port.isEmpty()) detail = detail.isEmpty() ? "Port: " + port : detail + ":" + port;
                            if (detail.isEmpty()) detail = obj.toString();
                            addServerCard(name, detail);
                        } else {
                            addServerCard("Server " + (i + 1), String.valueOf(item));
                        }
                    }
                    status.setText("Loaded " + items.length() + " server entr" + (items.length() == 1 ? "y." : "ies."));
                });
            } catch (Exception e) {
                String message = e.getMessage() == null ? "Could not load JSON." : e.getMessage();
                runOnUiThread(() -> status.setText("Load failed: " + message + ". Check the Dropbox link and JSON format."));
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }

    private JSONArray extractServers(String text) throws Exception {
        Object parsed = new JSONTokener(text).nextValue();
        if (parsed instanceof JSONArray) return (JSONArray) parsed;
        if (parsed instanceof JSONObject) {
            JSONObject object = (JSONObject) parsed;
            String[] keys = {"servers", "server_list", "serverList", "data", "items"};
            for (String key : keys) {
                Object value = object.opt(key);
                if (value instanceof JSONArray) return (JSONArray) value;
            }
            JSONArray one = new JSONArray();
            one.put(object);
            return one;
        }
        throw new Exception("The file is not a JSON array/object");
    }

    private String firstString(JSONObject o, String... keys) {
        for (String key : keys) {
            Object v = o.opt(key);
            if (v != null && !(v instanceof JSONObject) && !(v instanceof JSONArray)) {
                String s = String.valueOf(v).trim();
                if (!s.isEmpty() && !s.equals("null")) return s;
            }
        }
        return "";
    }

    private void addServerCard(String name, String detail) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackgroundTintList(null);
        card.setBackgroundColor(Color.rgb(31,31,31));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.bottomMargin = dp(10);
        serverList.addView(card, clp);

        TextView n = new TextView(this);
        n.setText(name);
        n.setTextColor(Color.WHITE);
        n.setTextSize(16);
        n.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(n);

        TextView d = new TextView(this);
        d.setText(detail);
        d.setTextColor(Color.LTGRAY);
        d.setTextSize(12);
        d.setPadding(0, dp(5), 0, 0);
        card.addView(d);
    }

    private boolean validUrl(String s) {
        return s.startsWith("https://") && s.contains("dropbox.com");
    }

    private String makeDropboxDirect(String s) {
        if (s.contains("dl=0")) return s.replace("dl=0", "dl=1");
        if (s.contains("dl=1")) return s;
        return s + (s.contains("?") ? "&" : "?") + "dl=1";
    }

    private void hideKeyboard() {
        try {
            ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(urlField.getWindowToken(), 0);
            urlField.clearFocus();
        } catch (Exception ignored) {}
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
